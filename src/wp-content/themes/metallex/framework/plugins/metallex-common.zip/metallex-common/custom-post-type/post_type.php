<?php
// register post type Projects
add_action( 'init', 'register_metallex_Projects' );
function register_metallex_Projects() {
    
    $labels = array( 
        'name' => __( 'Projects', 'metallex' ),
        'singular_name' => __( 'Projects', 'metallex' ),
        'add_new' => __( 'Add New Projects', 'metallex' ),
        'add_new_item' => __( 'Add New Projects', 'metallex' ),
        'edit_item' => __( 'Edit Projects', 'metallex' ),
        'new_item' => __( 'New Projects', 'metallex' ),
        'view_item' => __( 'View Projects', 'metallex' ),
        'search_items' => __( 'Search Projects', 'metallex' ),
        'not_found' => __( 'No Projects found', 'metallex' ),
        'not_found_in_trash' => __( 'No Projects found in Trash', 'metallex' ),
        'parent_item_colon' => __( 'Parent Projects:', 'metallex' ),
        'menu_name' => __( 'Projects', 'metallex' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'List Projects',
        'supports' => array( 'title', 'editor', 'thumbnail', 'comments'),
        'taxonomies' => array( 'Projects', 'type' ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'menu_icon' => get_stylesheet_directory_uri(). '/images/admin_ico.png', 
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_type' => 'post'
    );

    register_post_type( 'Projects', $args );
}
add_action( 'init', 'create_Type_hierarchical_taxonomy', 0 );

//create a custom taxonomy name it Skillss for your posts

function create_Type_hierarchical_taxonomy() {

// Add new taxonomy, make it hierarchical like Skills
//first do the translations part for GUI

  $labels = array(
    'name' => __( 'Type', 'metallex' ),
    'singular_name' => __( 'Type', 'metallex' ),
    'search_items' =>  __( 'Search Type','metallex' ),
    'all_items' => __( 'All Type','metallex' ),
    'parent_item' => __( 'Parent Type','metallex' ),
    'parent_item_colon' => __( 'Parent Type:','metallex' ),
    'edit_item' => __( 'Edit Type','metallex' ), 
    'update_item' => __( 'Update Type','metallex' ),
    'add_new_item' => __( 'Add New Type','metallex' ),
    'new_item_name' => __( 'New Type Name','metallex' ),
    'menu_name' => __( 'Type','metallex' ),
  );     

// Now register the taxonomy

  register_taxonomy('type',array('Projects'), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'type' ),
  ));

}

// register post type Solutions
add_action( 'init', 'register_metallex_Solutions' );
function register_metallex_Solutions() {
    
    $labels = array( 
        'name' => __( 'Solutions', 'metallex' ),
        'singular_name' => __( 'Solutions', 'metallex' ),
        'add_new' => __( 'Add New Solutions', 'metallex' ),
        'add_new_item' => __( 'Add New Solutions', 'metallex' ),
        'edit_item' => __( 'Edit Solutions', 'metallex' ),
        'new_item' => __( 'New Solutions', 'metallex' ),
        'view_item' => __( 'View Solutions', 'metallex' ),
        'search_items' => __( 'Search Solutions', 'metallex' ),
        'not_found' => __( 'No Solutions found', 'metallex' ),
        'not_found_in_trash' => __( 'No Solutions found in Trash', 'metallex' ),
        'parent_item_colon' => __( 'Parent Solutions:', 'metallex' ),
        'menu_name' => __( 'Solutions', 'metallex' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'List Solutions',
        'supports' => array( 'title', 'editor', 'thumbnail', 'comments'),
        'taxonomies' => array( 'Solutions', 'type1' ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'menu_icon' => get_stylesheet_directory_uri(). '/images/admin_ico.png', 
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_type' => 'post'
    );

    register_post_type( 'Solutions', $args );
}

?>