<?php
/**
 * Plugin Name: Meta Box
 * Plugin URI:  https://metabox.io
 * Description: Create custom meta boxes and custom fields in WordPress.
 * Version:     5.3.3
 * Author:      MetaBox.io
 * Author URI:  https://metabox.io
 * License:     GPL2+
 * Text Domain: meta-box
 * Domain Path: /languages/
 *
 * @package Meta Box
 */

if ( defined( 'ABSPATH' ) && ! defined( 'RWMB_VER' ) ) {
	register_activation_hook( __FILE__, 'rwmb_check_php_version' );

	/**
	 * Display notice for old PHP version.
	 */
	function rwmb_check_php_version() {
		if ( version_compare( phpversion(), '5.3', '<' ) ) {
			die( esc_html__( 'Meta Box requires PHP version 5.3+. Please contact your host to upgrade.', 'meta-box' ) );
		}
	}




	require_once dirname( __FILE__ ) . '/inc/loader.php';
	$rwmb_loader = new RWMB_Loader();
	$rwmb_loader->init();


	add_filter( 'rwmb_meta_boxes', function ( $meta_boxes ) {

	$prefix = '_cmb_';


  // Open Code



    $meta_boxes[] = array(
        'id'         => 'page_setting',
        'title'      => 'Page Setting',
        'pages'      => array('page'), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
        'fields' => array(
            array(
                'name' => 'Page Image',
                'desc' => 'Input Page Image background',
                'id'   => $prefix . 'page_image',
                'type'    => 'file',
            ),
        )
    );

    $meta_boxes[] = array(
        'id'         => 'post_setting',
        'title'      => 'Post Setting',
        'pages'      => array('post'), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
        'fields' => array(
            array(
                'name' => 'Link share facebook',
                'desc' => 'Input Link share facebook',
                'id'   => $prefix . 'post_facebook',
                'type'    => 'text',
            ),
            array(
                'name' => 'Link share twitter',
                'desc' => 'Input Link share twitter',
                'id'   => $prefix . 'post_twitter',
                'type'    => 'text',
            ),
            array(
                'name' => 'Link share google',
                'desc' => 'Input Link share google',
                'id'   => $prefix . 'post_google',
                'type'    => 'text',
            ),
            array(
                'name' => 'Link share linkedin',
                'desc' => 'Input Link share linkedin',
                'id'   => $prefix . 'post_linkedin',
                'type'    => 'text',
            ),
            array(
                'name' => 'Selected Type Sidebar',
                'desc' => 'Type Sidebar on Single Post',
                'id'   => $prefix . 'post_sidebar',
                'type'    => 'select',
                'options' => array(
                        array( 'name' => 'Right Sidebar', 'value' => 'right', ),
                        array( 'name' => 'Left Sidebar', 'value' => 'left', ),
                        ),
                    'default' => 'right',
            ),
        )
    );

    $meta_boxes[] = array(
        'id'         => 'product_setting',
        'title'      => 'Product Specification',
        'pages'      => array('product'), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
        'fields' => array(
            array(
                'name' => 'Product Specification',
                'desc' => 'Input Product Specification',
                'id'   => $prefix . 'product_spe',
                'type'    => 'textarea',
            ),
        )
    );



// End Code



    return $meta_boxes;
});
}
